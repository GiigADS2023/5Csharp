﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*5 - Crie uma matriz bidimensional. Deverá ser solicitado três nomes de 
             * alunos e quatro notas, após solicitação dos nomes e das notas deverá 
             * ser impresso os nomes acompanhados da média geral de cada aluno, deverá 
             * ser impresso também o nome do aluno que obteve a maior média e o nome do 
             * aluno que obteve a menor média.*/

            //Armazena a nota dos alunos 
            double[,] notas = new double[3, 4]; // 3 - alunos, 4 - notas

            //Solicita nome 
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Digite o nome do " + (i + 1) + "º aluno:");
                string nomeAluno = Console.ReadLine();

                //Solicita nota dos alunos
                for (int a = 0; a < 4; a++)
                {
                    Console.Write("Digite a "+ (a + 1) + "ª nota do " + nomeAluno);
                    notas[i, a] = double.Parse(Console.ReadLine());
                }
            }
           
            // Média das notas
            double[] medias = new double[3];
            double maiorMedia = double.MinValue;
            string alunoMaiorMedia = "";
            double menorMedia = double.MaxValue;
            string alunoMenorMedia = "";

            for (int i = 0; i < 3; i++)
            {
                double somaNotas = 0;

                for (int a = 0; a < 4; a++)
                {
                    somaNotas += notas[i, a];
                }

                medias[i] = somaNotas / 4;

                if (medias[i] > maiorMedia)
                {
                    maiorMedia = medias[i];
                    alunoMaiorMedia = "Aluno " + (i + 1);
                }

                if (medias[i] < menorMedia)
                {
                    menorMedia = medias[i];
                    alunoMenorMedia = "Aluno " + (i + 1);
                }
            }

            // Impressão dos nomes acompanhados da média geral de cada aluno
            Console.WriteLine("Médias dos alunos:");
            for (int i = 0; i < 3; i++)
            {
                Console.WriteLine("Aluno " + (i + 1) + ": " + medias[i]);
                Console.ReadLine();
            }

            // Impressão do aluno com maior e menor média
            Console.WriteLine("Aluno com a maior média: " + alunoMaiorMedia + " (média = " + maiorMedia + ")");
            Console.WriteLine("Aluno com a menor média: " + alunoMenorMedia + " (média = " + menorMedia + ")");
            Console.ReadLine();
        }
    }
}